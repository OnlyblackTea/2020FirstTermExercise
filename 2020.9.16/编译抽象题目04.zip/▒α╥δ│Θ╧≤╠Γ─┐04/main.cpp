#include "Calc.h"

int main()
{
	
	return 1;
	
}