// Calc.h: interface for the CCalc class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALC_H__8DA1405F_D114_43FB_8E28_EFAE7B89BAAC__INCLUDED_)
#define AFX_CALC_H__8DA1405F_D114_43FB_8E28_EFAE7B89BAAC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

void fun();

class CCalc  
{
public:
	CCalc();
	virtual ~CCalc();

};

#endif // !defined(AFX_CALC_H__8DA1405F_D114_43FB_8E28_EFAE7B89BAAC__INCLUDED_)