// Test.h: interface for the Test class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEST_H__6761840F_F930_4391_9B8C_19422C776ADF__INCLUDED_)
#define AFX_TEST_H__6761840F_F930_4391_9B8C_19422C776ADF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Test  
{
public:
	Test();
	virtual ~Test();

	int f();
	int m_iId;

};

#endif // !defined(AFX_TEST_H__6761840F_F930_4391_9B8C_19422C776ADF__INCLUDED_)