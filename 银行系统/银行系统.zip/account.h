#ifndef M_ACCOUNT_HEADER
#define M_ACCOUNT_HEADER

#include<vector>
#include<string>
#include"date.h"
using namespace std;
class SavingsAccount{
private:
    string id;
    Date lastDate;
    double rate, balance, accumulation;
    static double total;
public: 
    SavingsAccount(Date date, string id, double rate);
    void record(Date date, double amount);
    double accumulate(int date);
    int getId();
    double getBalance();
    double getRate();
    static double getTotal();
    void show();
    void deposit(Date date, double amount, string commit);
    void withdraw(Date date, double amount, string commit);
    void settle(Date date);
    void print(Date date, string id);
    void print(Date date, string id, double amount, double balance, string commit);
};

#endif